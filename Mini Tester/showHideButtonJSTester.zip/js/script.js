function hide() {
    var x = document.getElementById("elemen2");
    if (x.style.display === "block") {
        x.style.display = "none";
     } else {
        x.style.display = "none";
     }}


  function show() {
    var y = document.getElementById("elemen2");
    if (y.style.display === "none") {
        y.style.display = "block";
  }else {
        y.style.display = "block";
    }
}